import UIKit

enum bread: CaseIterable {
    case whole, white, italian, american
}
enum condiments: CaseIterable {
    case miracleWhip, sweetOnion, mustard, relish
}
enum vegetables: CaseIterable {
    case lettuce, tomato, cucumber, pickles
}
enum meat: CaseIterable {
    case chicken, tuna, turkey, veggiePattie
}
print ("when I go to subway, I get the \(meat.tuna) one-foot with: \(bread.italian) herb bread \(vegetables.lettuce) \(vegetables.cucumber)| \(vegetables.pickles) \(vegetables.tomato), \(condiments.sweetOnion) sauce, and \(condiments.mustard).")
